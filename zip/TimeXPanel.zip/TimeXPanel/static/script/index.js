const Color = ["color1", "color2"];

const Theme = {
    color1: "#91C1F9",
    color2: "#d8ecf9",
};

var Main = {
    methods: {
        open1(message) {
            this.$message({
                showClose: true,
                message: message,
            });
        },
        open2(message) {
            this.$message({
                showClose: true,
                message: message,
                type: "success",
            });
        },
        open3(message) {
            this.$message({
                showClose: true,
                message: message,
                type: "warning",
            });
        },
        open4(message) {
            this.$message({
                showClose: true,
                message: message,
                type: "error",
            });
        },
        dialog(message) {
            this.$confirm(message)
                .then(_ => {
                    done();
                })
                .catch(_ => { });
        }
    },
};

var Ctor = Vue.extend(Main);

var app = new Vue({
    el: ".el-container",
    data() {
        show: true;
        return {
            input: '',
            name: "时光控制面板",
            fullscreenLoading: true,
            Version: "Beta-1.1.3 测试版"
        }
    },
    mounted() {
        for (i in Color) {
            document.documentElement.style.setProperty(`--${Color[i]}`,Theme[Color[i]]);
        }
        setTimeout(() => {
            this.fullscreenLoading = false;
        }, 2000);
    }
});

window.onload = () => {
    document.body.style.opacity = "1";
    document.querySelector("button.button-login").onclick = () => {
        new Ctor().$mount("index-main").open3("时光面板正在开发中，敬请期待！");
    };

    document.querySelector("a.more-link.link-password").onclick = () => {
        new Ctor().$mount("index-main").dialog("请前往控制台或者SSH终端重置密码。");
    };
    document.querySelector("body").style.backgroundImage =
        'url("https://timex-1309511642.cos.ap-shanghai.myqcloud.com/panel/static/background.jpg")';
};